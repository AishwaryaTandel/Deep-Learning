class BaseLayer:
    def __init__(self):
        trainable = False