class BaseLayer:
    def __init__(self, trainable=False):
        self.testing_phase = False
